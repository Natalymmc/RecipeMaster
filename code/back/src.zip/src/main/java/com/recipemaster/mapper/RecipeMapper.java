package com.recipemaster.mapper;

import com.recipemaster.dto.CreateRecipeDTO;
import com.recipemaster.dto.IngredientDTO;
import com.recipemaster.dto.RecipeDTO;
import com.recipemaster.dto.StepDTO;
import com.recipemaster.entity.*;
import com.recipemaster.repository.FavoriteRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class RecipeMapper {

    private final IngredientMapper ingredientMapper;
    private final StepMapper stepMapper;

    @Autowired
    private FavoriteRepository favoriteRepository;

    public RecipeMapper(IngredientMapper ingredientMapper, StepMapper stepMapper) {
        this.ingredientMapper = ingredientMapper;
        this.stepMapper = stepMapper;
    }

    // Entity to DTO
    public RecipeDTO toDTO(Recipe recipe, Long currentUserId) {
        RecipeDTO dto = new RecipeDTO();
        dto.setId(recipe.getId());
        dto.setTitle(recipe.getTitle());
        dto.setImageUrl(recipe.getImageUrl());
        dto.setCategory(recipe.getCategory());
        dto.setCookingTime(recipe.getCookingTime());
        dto.setDifficulty(recipe.getDifficulty());
        dto.setPortions(recipe.getPortions());
        dto.setDescription(recipe.getDescription());
        dto.setCreatedAt(recipe.getCreatedAt());
        dto.setAuthorUsername(recipe.getUser() != null ? recipe.getUser().getUsername() : null);

        // ФИКС: Конвертируем Set<Entity> → List<DTO>
        dto.setIngredients(ingredientMapper.toDTOList(new ArrayList<>(recipe.getIngredients())));
        dto.setSteps(stepMapper.toDTOList(new ArrayList<>(recipe.getSteps())));

        // Логика isFavorite
        boolean isFav = false;
        if (currentUserId != null && currentUserId > 0) {
            isFav = favoriteRepository.findByUserIdAndRecipeId(currentUserId, recipe.getId()).isPresent();
        }
        dto.setIsFavorite(isFav);

        return dto;
    }

    public List<RecipeDTO> toDTOList(List<Recipe> recipes, Long currentUserId) {
        return recipes.stream()
                .map(recipe -> toDTO(recipe, currentUserId))
                .collect(Collectors.toList());
    }

    // CreateDTO to Entity
    public Recipe toEntity(CreateRecipeDTO dto, User user) {
        Recipe recipe = new Recipe();
        recipe.setTitle(dto.getTitle());
        recipe.setImageUrl(dto.getImageUrl());
        recipe.setCategory(dto.getCategory());
        recipe.setCookingTime(dto.getCookingTime());
        recipe.setDifficulty(dto.getDifficulty());
        recipe.setPortions(dto.getPortions());
        recipe.setDescription(dto.getDescription());
        recipe.setUser(user);
        return recipe;
    }

    // Геттеры для вложенных мапперов
    public IngredientMapper getIngredientMapper() {
        return ingredientMapper;
    }

    public StepMapper getStepMapper() {
        return stepMapper;
    }
}