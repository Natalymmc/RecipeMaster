package com.recipemaster.dto;

import com.recipemaster.entity.Category;
import com.recipemaster.entity.Difficulty;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import java.util.List;

public class CreateRecipeDTO {
    @NotBlank
    private String title;
    private String imageUrl;
    @NotNull
    private Category category;
    @NotNull
    private Integer cookingTime;
    @NotNull
    private Difficulty difficulty;
    private Integer portions;
    private String description;
    private List<IngredientDTO> ingredients;
    private List<StepDTO> steps;

    public CreateRecipeDTO() {}

    public String getTitle(){return title;}
    public void setTitle(String title){this.title=title;}

    public String getImageUrl(){return imageUrl;}
    public void setImageUrl(String imageUrl){this.imageUrl=imageUrl;}

    public Category getCategory(){return category;}
    public void setCategory(Category category){this.category=category;}

    public Integer getCookingTime(){return cookingTime;}
    public void setCookingTime(Integer cookingTime){this.cookingTime=cookingTime;}

    public Difficulty getDifficulty(){return difficulty;}
    public void setDifficulty(Difficulty difficulty){this.difficulty=difficulty;}

    public Integer getPortions(){return portions;}
    public void setPortions(Integer portions){this.portions=portions;}

    public String getDescription(){return description;}
    public void setDescription(String description){this.description=description;}

    public List<IngredientDTO> getIngredients(){return ingredients;}
    public void setIngredients(List<IngredientDTO> ingredients){this.ingredients=ingredients;}

    public List<StepDTO> getSteps(){return steps;}
    public void setSteps(List<StepDTO> steps){this.steps=steps;}
}
