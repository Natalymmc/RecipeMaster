package com.recipemaster.dto;

import com.recipemaster.entity.Category;
import com.recipemaster.entity.Difficulty;
import java.time.LocalDateTime;
import java.util.List;

public class RecipeDTO {
    private Long id;
    private String title;
    private String imageUrl;
    private Category category;
    private Integer cookingTime;
    private Difficulty difficulty;
    private Integer portions;
    private String description;
    private LocalDateTime createdAt;
    private String authorUsername; // from user
    private List<IngredientDTO> ingredients;
    private List<StepDTO> steps;
    private boolean isFavorite; // Добавлено: для индикации избранного для текущего пользователя

    // Constructors
    public RecipeDTO() {}

    // Getters and Setters
    public Long getId() { return id; }
    public void setId(Long id) { this.id = id; }

    public String getTitle() { return title; }
    public void setTitle(String title) { this.title = title; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) { this.category = category; }

    public Integer getCookingTime() { return cookingTime; }
    public void setCookingTime(Integer cookingTime) { this.cookingTime = cookingTime; }

    public Difficulty getDifficulty() { return difficulty; }
    public void setDifficulty(Difficulty difficulty) { this.difficulty = difficulty; }

    public Integer getPortions() { return portions; }
    public void setPortions(Integer portions) { this.portions = portions; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public LocalDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(LocalDateTime createdAt) { this.createdAt = createdAt; }

    public String getAuthorUsername() { return authorUsername; }
    public void setAuthorUsername(String authorUsername) { this.authorUsername = authorUsername; }

    public List<IngredientDTO> getIngredients() { return ingredients; }
    public void setIngredients(List<IngredientDTO> ingredients) { this.ingredients = ingredients; }

    public List<StepDTO> getSteps() { return steps; }
    public void setSteps(List<StepDTO> steps) { this.steps = steps; }

    // Добавлено: Геттер и сеттер для isFavorite
    public boolean isFavorite() { return isFavorite; }
    public void setIsFavorite(boolean isFavorite) { this.isFavorite = isFavorite; }
}