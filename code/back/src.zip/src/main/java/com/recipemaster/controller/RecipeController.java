package com.recipemaster.controller;

import com.recipemaster.dto.CreateRecipeDTO;
import com.recipemaster.dto.RecipeDTO;
import com.recipemaster.entity.Category;
import com.recipemaster.entity.Difficulty;
import com.recipemaster.service.AuthService;
import com.recipemaster.service.RecipeService;
import jakarta.validation.Valid;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/recipes")
@CrossOrigin(origins = "http://localhost:5173")
public class RecipeController {

    @Autowired
    private RecipeService recipeService;

    @Autowired
    private AuthService authService;  // Для getCurrentUserId из токена

    @GetMapping
    public ResponseEntity<List<RecipeDTO>> getAllRecipes() {
        Long currentUserId = authService.getCurrentUserId();  // Из JWT токена
        return ResponseEntity.ok(recipeService.getAllRecipes(currentUserId));
    }

    @GetMapping("/{id}")
    public ResponseEntity<RecipeDTO> getRecipe(@PathVariable Long id) {
        Long currentUserId = authService.getCurrentUserId();
        return ResponseEntity.ok(recipeService.getRecipeById(id, currentUserId));
    }

    @PostMapping
    public ResponseEntity<RecipeDTO> createRecipe(@Valid @RequestBody CreateRecipeDTO dto) {
        Long userId = authService.getCurrentUserId();  // Только из токена
        return ResponseEntity.ok(recipeService.createRecipe(dto, userId));
    }

    @PutMapping("/{id}")
    public ResponseEntity<RecipeDTO> updateRecipe(@PathVariable Long id, @Valid @RequestBody CreateRecipeDTO dto) {
        Long userId = authService.getCurrentUserId();
        return ResponseEntity.ok(recipeService.updateRecipe(id, dto, userId));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> deleteRecipe(@PathVariable Long id) {
        Long userId = authService.getCurrentUserId();
        recipeService.deleteRecipe(id, userId);
        return ResponseEntity.noContent().build();
    }

    @GetMapping("/search")
    public ResponseEntity<List<RecipeDTO>> search(
            @RequestParam(required = false) String query,
            @RequestParam(required = false) String categoryParam,
            @RequestParam(required = false) String difficultyParam,
            @RequestParam(defaultValue = "recent") String sortBy) {
        Long currentUserId = authService.getCurrentUserId();
        Category category = null;
        if (categoryParam != null && !categoryParam.isEmpty()) {
            try {
                category = Category.valueOf(categoryParam.toUpperCase());
            } catch (IllegalArgumentException e) {
                // Ignore invalid
            }
        }
        Difficulty difficulty = null;
        if (difficultyParam != null && !difficultyParam.isEmpty()) {
            try {
                difficulty = Difficulty.valueOf(difficultyParam.toUpperCase());
            } catch (IllegalArgumentException e) {
                // Ignore invalid
            }
        }
        return ResponseEntity.ok(recipeService.searchRecipes(query, category, difficulty, sortBy, currentUserId));
    }

    @GetMapping("/recent")
    public ResponseEntity<List<RecipeDTO>> getRecent() {
        Long currentUserId = authService.getCurrentUserId();
        return ResponseEntity.ok(recipeService.getRecentRecipes(5, currentUserId));
    }

    @PostMapping("/{recipeId}/favorites")
    public ResponseEntity<Void> addFavorite(@PathVariable Long recipeId) {
        Long userId = authService.getCurrentUserId();
        recipeService.addToFavorites(userId, recipeId);
        return ResponseEntity.ok().build();
    }

    @DeleteMapping("/{recipeId}/favorites")
    public ResponseEntity<Void> removeFavorite(@PathVariable Long recipeId) {
        Long userId = authService.getCurrentUserId();
        recipeService.removeFromFavorites(userId, recipeId);
        return ResponseEntity.ok().build();
    }

    @GetMapping("/favorites")
    public ResponseEntity<List<RecipeDTO>> getFavorites() {
        Long userId = authService.getCurrentUserId();
        return ResponseEntity.ok(recipeService.getFavoritesForUser(userId));
    }
}