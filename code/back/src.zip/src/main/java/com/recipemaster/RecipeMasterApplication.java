package com.recipemaster;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecipeMasterApplication {

    public static void main(String[] args) {
        SpringApplication.run(RecipeMasterApplication.class, args);
    }

}
