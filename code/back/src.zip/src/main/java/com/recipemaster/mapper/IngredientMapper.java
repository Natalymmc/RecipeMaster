package com.recipemaster.mapper;

import com.recipemaster.dto.IngredientDTO;
import com.recipemaster.entity.Ingredient;
import com.recipemaster.entity.Recipe;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class IngredientMapper {

    // ФИКС: toDTOList принимает Iterable (Set/List оба Iterable, используем stream)
    public List<IngredientDTO> toDTOList(Iterable<Ingredient> ingredients) {
        return java.util.stream.StreamSupport.stream(ingredients.spliterator(), false)
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public IngredientDTO toDTO(Ingredient ingredient) {
        IngredientDTO dto = new IngredientDTO();
        dto.setId(ingredient.getId());
        dto.setName(ingredient.getName());
        dto.setAmount(ingredient.getAmount());
        return dto;
    }

    // DTO to Entity (для create, ID null)
    public Ingredient toEntity(IngredientDTO dto, Recipe recipe) {
        Ingredient ingredient = new Ingredient();
        ingredient.setName(dto.getName());
        ingredient.setAmount(dto.getAmount());
        ingredient.setRecipe(recipe);
        return ingredient;
    }

    // ФИКС: toEntityList возвращает List, toEntitySet — Set
    public List<Ingredient> toEntityList(List<IngredientDTO> dtos, Recipe recipe) {
        return dtos.stream()
                .map(dto -> toEntity(dto, recipe))
                .collect(Collectors.toList());
    }

    public Set<Ingredient> toEntitySet(List<IngredientDTO> dtos, Recipe recipe) {
        return dtos.stream()
                .map(dto -> toEntity(dto, recipe))
                .collect(Collectors.toSet());
    }
}