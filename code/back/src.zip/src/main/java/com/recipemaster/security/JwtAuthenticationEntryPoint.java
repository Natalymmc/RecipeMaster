package com.recipemaster.security;

import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.springframework.http.HttpStatus;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.AuthenticationEntryPoint;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Component
public class JwtAuthenticationEntryPoint implements AuthenticationEntryPoint {

    private final ObjectMapper objectMapper = new ObjectMapper();  // Для JSON

    @Override
    public void commence(HttpServletRequest request, HttpServletResponse response,
                         AuthenticationException authException) throws IOException, ServletException {

        // Лог для дебага
        System.err.println("Unauthorized error: " + authException.getMessage());
        System.err.println("Request URI: " + request.getRequestURI());
        System.err.println("Auth header: " + request.getHeader("Authorization"));

        response.setStatus(HttpServletResponse.SC_UNAUTHORIZED);
        response.setContentType("application/json");
        response.setCharacterEncoding("UTF-8");

        // JSON-ответ с деталями ошибки
        Map<String, Object> error = new HashMap<>();
        error.put("timestamp", System.currentTimeMillis());
        error.put("status", HttpStatus.UNAUTHORIZED.value());
        error.put("error", "Unauthorized");
        error.put("message", authException.getMessage() != null ? authException.getMessage() : "JWT token invalid or missing");
        error.put("path", request.getRequestURI());

        try {
            objectMapper.writeValue(response.getOutputStream(), error);
        } catch (Exception e) {
            // Fallback: plain text, если JSON fails
            response.getWriter().println("{\"error\": \"Unauthorized: " + authException.getMessage() + "\"}");
        }
    }
}