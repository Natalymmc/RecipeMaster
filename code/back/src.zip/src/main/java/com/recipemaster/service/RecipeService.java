package com.recipemaster.service;

import com.recipemaster.dto.CreateRecipeDTO;
import com.recipemaster.dto.IngredientDTO;
import com.recipemaster.dto.RecipeDTO;
import com.recipemaster.dto.StepDTO;
import com.recipemaster.entity.*;
import com.recipemaster.exception.NotFoundException;
import com.recipemaster.mapper.RecipeMapper;
import com.recipemaster.repository.*;
import org.hibernate.Hibernate;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Service
@Transactional
public class RecipeService {

    private final RecipeRepository recipeRepository;
    private final UserRepository userRepository;
    private final IngredientRepository ingredientRepository;
    private final StepRepository stepRepository;
    private final FavoriteRepository favoriteRepository;
    private final RecipeMapper recipeMapper;

    // Используем constructor injection для избежания null
    public RecipeService(RecipeRepository recipeRepository, UserRepository userRepository,
                         IngredientRepository ingredientRepository, StepRepository stepRepository,
                         FavoriteRepository favoriteRepository, RecipeMapper recipeMapper) {
        this.recipeRepository = recipeRepository;
        this.userRepository = userRepository;
        this.ingredientRepository = ingredientRepository;
        this.stepRepository = stepRepository;
        this.favoriteRepository = favoriteRepository;
        this.recipeMapper = recipeMapper;
    }

    public List<RecipeDTO> getAllRecipes(Long currentUserId) {
        return recipeMapper.toDTOList(recipeRepository.findAll(), currentUserId);
    }

    public RecipeDTO getRecipeById(Long id, Long currentUserId) {
        Recipe recipe = recipeRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Recipe not found with ID " + id));
        return recipeMapper.toDTO(recipe, currentUserId);
    }

    public RecipeDTO createRecipe(CreateRecipeDTO dto, Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("User not found with ID " + userId));

        Recipe recipe = recipeMapper.toEntity(dto, user);
        recipe = recipeRepository.save(recipe);

        // Add ingredients (Set in entity, List in DTO — конвертируем)
        if (dto.getIngredients() != null && !dto.getIngredients().isEmpty()) {
            Set<Ingredient> newIngredients = new HashSet<>();
            for (IngredientDTO ingDto : dto.getIngredients()) {
                Ingredient ing = new Ingredient(ingDto.getName(), ingDto.getAmount(), recipe);
                newIngredients.add(ingredientRepository.save(ing));
            }
            recipe.setIngredients(newIngredients);
        }

        // Add steps (Set in entity, List in DTO)
        if (dto.getSteps() != null && !dto.getSteps().isEmpty()) {
            int num = 1;
            Set<Step> newSteps = new HashSet<>();
            for (StepDTO stepDto : dto.getSteps()) {
                if (stepDto.getStepNumber() == null) {
                    stepDto.setStepNumber(num++);
                }
                Step step = new Step(stepDto.getStepNumber(), stepDto.getDescription(), recipe);
                newSteps.add(stepRepository.save(step));
            }
            recipe.setSteps(newSteps);
        }

        recipe = recipeRepository.save(recipe); // Re-save to persist relations
        return recipeMapper.toDTO(recipe, userId);
    }
    @Transactional
    public RecipeDTO updateRecipe(Long recipeId, CreateRecipeDTO recipeDto, Long userId) {
        // Получаем рецепт из базы данных
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new NotFoundException("Recipe not found with ID " + recipeId));

        if (!recipe.getUser().getId().equals(userId)) {
            throw new NotFoundException("Unauthorized to update this recipe");
        }

        // Обновляем основные поля
        recipe.setTitle(recipeDto.getTitle());
        recipe.setDescription(recipeDto.getDescription());
        recipe.setCategory(recipeDto.getCategory());
        recipe.setCookingTime(recipeDto.getCookingTime());
        recipe.setDifficulty(recipeDto.getDifficulty());
        recipe.setPortions(recipeDto.getPortions());
        recipe.setImageUrl(recipeDto.getImageUrl());

        // Обрабатываем ингредиенты (адаптировано: clear + addAll для fix dereference)
        if (recipeDto.getIngredients() != null) {
            Hibernate.initialize(recipe.getIngredients()); // Load lazy
            recipe.getIngredients().clear(); // Mark old as orphans

            Set<Ingredient> updatedIngredients = new HashSet<>();
            for (IngredientDTO ingredientDto : recipeDto.getIngredients()) {
                if (ingredientDto.getId() == null) {
                    // New ingredient
                    Ingredient newIng = new Ingredient(ingredientDto.getName(), ingredientDto.getAmount(), recipe);
                    updatedIngredients.add(ingredientRepository.save(newIng));
                } else {
                    // Existing
                    Ingredient ingredient = ingredientRepository.findById(ingredientDto.getId())
                            .orElseThrow(() -> new NotFoundException("Ingredient not found with ID " + ingredientDto.getId()));
                    updatedIngredients.add(ingredient);
                }
            }
            recipe.getIngredients().addAll(updatedIngredients); // Add to existing collection
        }

        // Аналогично для шагов (List<DTO> -> Set<Entity>)
        if (recipeDto.getSteps() != null) {
            Hibernate.initialize(recipe.getSteps());
            recipe.getSteps().clear();

            Set<Step> updatedSteps = new HashSet<>();
            int num = 1;
            for (StepDTO stepDto : recipeDto.getSteps()) {
                if (stepDto.getId() == null) {
                    if (stepDto.getStepNumber() == null) stepDto.setStepNumber(num++);
                    Step newStep = new Step(stepDto.getStepNumber(), stepDto.getDescription(), recipe);
                    updatedSteps.add(stepRepository.save(newStep));
                } else {
                    Step step = stepRepository.findById(stepDto.getId())
                            .orElseThrow(() -> new NotFoundException("Step not found with ID " + stepDto.getId()));
                    updatedSteps.add(step);
                }
            }
            recipe.getSteps().addAll(updatedSteps);
        }

        // Сохраняем изменения
        Recipe updatedRecipe = recipeRepository.save(recipe);

        return recipeMapper.toDTO(updatedRecipe, userId);
    }

    public void deleteRecipe(Long id, Long userId) {
        Recipe recipe = recipeRepository.findById(id)
                .orElseThrow(() -> new NotFoundException("Recipe not found with ID " + id));
        if (!recipe.getUser().getId().equals(userId)) {
            throw new NotFoundException("Unauthorized to delete this recipe");
        }
        // Как в примере: Clear коллекции для orphanRemoval
        Hibernate.initialize(recipe.getIngredients());
        recipe.getIngredients().clear();
        recipeRepository.save(recipe);  // Flush orphans

        Hibernate.initialize(recipe.getSteps());
        recipe.getSteps().clear();
        recipeRepository.save(recipe);  // Flush orphans

        recipeRepository.delete(recipe); // Cascade deletes relations
    }

    public List<RecipeDTO> searchRecipes(String query, Category category, Difficulty difficulty, String sortBy, Long currentUserId) {
        Specification<Recipe> spec = Specification.where(null);
        if (query != null && !query.trim().isEmpty()) {
            spec = spec.and((root, cq, cb) ->
                    cb.or(
                            cb.like(cb.lower(root.get("title")), "%" + query.toLowerCase() + "%"),
                            cb.like(cb.lower(root.get("description")), "%" + query.toLowerCase() + "%")
                    ));
        }
        if (category != null) {
            spec = spec.and((root, cq, cb) -> cb.equal(root.get("category"), category));
        }
        if (difficulty != null) {
            spec = spec.and((root, cq, cb) -> cb.equal(root.get("difficulty"), difficulty));
        }
        List<Recipe> recipes = recipeRepository.findAll(spec);
        // Apply sorting
        if ("recent".equalsIgnoreCase(sortBy)) {
            recipes = recipes.stream()
                    .sorted((r1, r2) -> r2.getCreatedAt().compareTo(r1.getCreatedAt()))
                    .collect(Collectors.toList());
        } else if ("popular".equalsIgnoreCase(sortBy)) {
            recipes = recipes.stream()
                    .sorted((r1, r2) -> Integer.compare(r2.getFavorites().size(), r1.getFavorites().size()))
                    .collect(Collectors.toList());
        }
        return recipeMapper.toDTOList(recipes, currentUserId);
    }

    public List<RecipeDTO> getRecentRecipes(int limit, Long currentUserId) {
        List<Recipe> allRecent = recipeRepository.findRecentRecipes();
        List<Recipe> limitedRecent = allRecent.stream()
                .limit(Math.max(1, limit))
                .collect(Collectors.toList());
        return recipeMapper.toDTOList(limitedRecent, currentUserId);
    }

    public List<RecipeDTO> getFavoritesForUser(Long userId) {
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("User not found with ID " + userId));
        List<Recipe> favorites = user.getFavorites().stream()
                .map(Favorite::getRecipe)
                .collect(Collectors.toList());
        return recipeMapper.toDTOList(favorites, userId);
    }

    public void addToFavorites(Long userId, Long recipeId) {
        if (favoriteRepository.findByUserIdAndRecipeId(userId, recipeId).isPresent()) {
            throw new NotFoundException("Recipe already in favorites");
        }
        User user = userRepository.findById(userId)
                .orElseThrow(() -> new NotFoundException("User not found with ID " + userId));
        Recipe recipe = recipeRepository.findById(recipeId)
                .orElseThrow(() -> new NotFoundException("Recipe not found with ID " + recipeId));
        Favorite fav = new Favorite(user, recipe);
        favoriteRepository.save(fav);
    }

    public void removeFromFavorites(Long userId, Long recipeId) {
        favoriteRepository.deleteByUserIdAndRecipeId(userId, recipeId);
    }
}