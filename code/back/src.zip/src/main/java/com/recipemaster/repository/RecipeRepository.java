package com.recipemaster.repository;

import com.recipemaster.entity.Category;
import com.recipemaster.entity.Difficulty;
import com.recipemaster.entity.Recipe;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface RecipeRepository extends JpaRepository<Recipe, Long>, JpaSpecificationExecutor<Recipe> {
    List<Recipe> findByCategory(Category category);
    List<Recipe> findByDifficulty(Difficulty difficulty);
    List<Recipe> findByUserId(Long userId);

    @Query("SELECT r FROM Recipe r ORDER BY r.createdAt DESC")
    List<Recipe> findRecentRecipes();

    // Для избранного: custom query if needed
}