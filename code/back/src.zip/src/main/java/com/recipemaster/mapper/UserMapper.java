package com.recipemaster.mapper;

import com.recipemaster.dto.UserDTO; // Добавь UserDTO если нужно, для простоты базовый
import com.recipemaster.entity.User;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.stream.Collectors;

@Component
public class UserMapper {

    // Entity to DTO (простой, расширь по необходимости)
    public UserDTO toDTO(User user) {
        UserDTO dto = new UserDTO();
        dto.setId(user.getId());
        dto.setUsername(user.getUsername());
        dto.setEmail(user.getEmail());
        // dto.setCreatedAt(user.getCreatedAt()); // если нужно
        return dto;
    }

    public List<UserDTO> toDTOList(List<User> users) {
        return users.stream()
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    // DTO to Entity (для регистрации)
    public User toEntity(UserDTO dto) {
        User user = new User();
        user.setUsername(dto.getUsername());
        user.setEmail(dto.getEmail());
        user.setPassword(dto.getPassword()); // hash в service
        return user;
    }
}