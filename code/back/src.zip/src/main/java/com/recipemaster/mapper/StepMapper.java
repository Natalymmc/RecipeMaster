package com.recipemaster.mapper;

import com.recipemaster.dto.StepDTO;
import com.recipemaster.entity.Recipe;
import com.recipemaster.entity.Step;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.Set;
import java.util.stream.Collectors;

@Component
public class StepMapper {

    // ФИКС: toDTOList для Iterable
    public List<StepDTO> toDTOList(Iterable<Step> steps) {
        return java.util.stream.StreamSupport.stream(steps.spliterator(), false)
                .map(this::toDTO)
                .collect(Collectors.toList());
    }

    public StepDTO toDTO(Step step) {
        StepDTO dto = new StepDTO();
        dto.setId(step.getId());
        dto.setStepNumber(step.getStepNumber());
        dto.setDescription(step.getDescription());
        return dto;
    }

    public Step toEntity(StepDTO dto, Recipe recipe) {
        Step step = new Step();
        step.setStepNumber(dto.getStepNumber());
        step.setDescription(dto.getDescription());
        step.setRecipe(recipe);
        return step;
    }

    // ФИКС: toEntityList и toEntitySet
    public List<Step> toEntityList(List<StepDTO> dtos, Recipe recipe) {
        return dtos.stream()
                .map(dto -> toEntity(dto, recipe))
                .collect(Collectors.toList());
    }

    public Set<Step> toEntitySet(List<StepDTO> dtos, Recipe recipe) {
        return dtos.stream()
                .map(dto -> toEntity(dto, recipe))
                .collect(Collectors.toSet());
    }
}