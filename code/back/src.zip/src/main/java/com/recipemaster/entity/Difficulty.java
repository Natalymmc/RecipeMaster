package com.recipemaster.entity;

public enum Difficulty {
    EASY, MEDIUM, HARD
}