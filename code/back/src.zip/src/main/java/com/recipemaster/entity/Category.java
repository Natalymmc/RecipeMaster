package com.recipemaster.entity;

public enum Category {
    DESSERT, MAIN, SALAD, PASTA, PIZZA, OTHER
}